﻿namespace Praktikumsaufgabe_2__Verkettete_Prioritätsliste_
{
    /// <summary>
    /// Priority: top(0), hoch(1), normal(2), niedrig(3)
    /// </summary>
    enum Prioritaet
    {
        top,
        hoch,
        normal,
        niedrig
    }
}
