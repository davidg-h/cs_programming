﻿using System;

namespace Weihnachten
{
    enum Verhalten
    {
        Frech = 0,
        OftLieb,
        MeistLieb,
        ImmerLieb,
    }

    class Program
    {
        static void Test()
        {

            Kind k = new Kind("Aris", Verhalten.MeistLieb);
            Console.WriteLine($"{k.AlsString()}");
            Console.WriteLine($"Kind {k.Name} hat keine Wünsche: {k.Wunschlos}\n");                    // beginn keine wünsche in der Liste
            Console.WriteLine("Es werden jetzt Wünsche hinzugefügt:");
            k.WunschAnhaengen("Sandspielzeug");
            k.WunschAnhaengen("Bausteine");
            k.WunschAnhaengen("Puppen");
            k.WunschAnhaengen("Tennisschläger");                                                       // Wunsch zu viel wird ignoriert
            k.WunschAusgeben();
            Console.WriteLine($"\nKind {k.Name} hat keine Wünsche: {k.Wunschlos}");                    // nachdem Wünsche zugrfügt wurden ist es false
            Console.WriteLine($"\nKind {k.Name} war lieb: {k.WarLieb}");
            Console.WriteLine();
            Console.WriteLine($"Wunsch schon vorhanden: {k.HatWunsch("Bausteine")}");                  // Prüft ob Bausteine in der Wunschliste schon vorkommt
            Console.WriteLine("\nBessert sich wird aufgerufen:");
            k.BessertSich();
            Console.WriteLine($"{k.AlsString()}");


            Console.WriteLine("\nNeuer Abschnitt: ---------------------------------------------\n");


            Kinderliste liste = new Kinderliste(10);
            liste.KindEintragen(k);                                                                                                                     // Aris wir eingetragen

            liste.KindEintragen(new Kind("Anton", Verhalten.ImmerLieb, new string[] { "Spielzeugauto", "Bausteine" }));
            liste.KindEintragen(new Kind("Emma", Verhalten.Frech, new string[] { "Spielekonsole" }));
            liste.KindEintragen(new Kind("Mehmet", Verhalten.OftLieb, new string[] { "Bausteine", "Spielesammlung", "Sandspielzeug", "Computer" }));
            liste.KindEintragen(new Kind("Esra", Verhalten.MeistLieb, new string[] { "Handy", "Kinogutschein" }));
            liste.KindEintragen(new Kind("Anna", Verhalten.OftLieb, new string[] { "Musikstream", "Chemiebaukasten" }));
            liste.KindEintragen(new Kind("Azra", Verhalten.MeistLieb, new string[] { "Elektronik-Baukasten", "Computer", "Handy" }));
            liste.KindEintragen(new Kind("Hans", Verhalten.Frech, new string[] { "Spielzeugautos", "Kinogutscheine" }));
            liste.KindEintragen(new Kind("Egon", Verhalten.ImmerLieb, new string[] { "Puppen", "Spielekonsole" }));
            liste.KindEintragen(new Kind("Marie", Verhalten.MeistLieb, new string[] { "Handy", "Spielekonsole" }));

            
            Console.WriteLine($"Anzahl lieber Kinder: {liste.AnzahlLieberKinder}");
            Console.WriteLine("So oft wünschen sich Kinder ...");
            foreach (string wunsch in new string[] { "Handy", "Computer", "Spielekonsole", "Bausteine", "Puppen" })
                Console.WriteLine($"... {wunsch}:   {liste.ZaehleKinderMitWunsch(wunsch)}");

        }

        static void Main(string[] args)
        {
            Test();
        }
    }
}
